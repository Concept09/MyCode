package com.zx.sms.codec.cmpp.packet;

/**
 *
 * @author huzorro(huzorro@gmail.com)
 */
public interface DataType {
    public int getCommandId(); 
    public int getAllCommandId();
}
