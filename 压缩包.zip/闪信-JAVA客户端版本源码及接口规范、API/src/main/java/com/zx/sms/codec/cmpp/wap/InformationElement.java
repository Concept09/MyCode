package com.zx.sms.codec.cmpp.wap;

import org.marre.sms.SmsUdhIei;

class InformationElement {

	SmsUdhIei udhIei;
	int infoEleLength;
	byte[] infoEleData;
}