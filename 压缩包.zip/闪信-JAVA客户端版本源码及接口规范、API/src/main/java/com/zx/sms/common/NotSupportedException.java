package com.zx.sms.common;

public class NotSupportedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7588016798736480605L;

	public NotSupportedException(String message) {
		super(message);
	}
}
