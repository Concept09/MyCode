package com.zx.sms.common;

public class SmsLifeTerminateException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SmsLifeTerminateException(String message) {
		super(message);
	}
}
