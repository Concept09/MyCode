package com.zx.sms.connect.manager;
/**
 *@author Lihuanghe(18852780@qq.com)
 */
public interface ClientEndpoint {

}
