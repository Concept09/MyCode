package com.zx.sms.mbean;

public interface ConnStateMBean {
	 public String print(String entityId);
}
