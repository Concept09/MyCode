package com.zx.sms.session.cmpp;

/**
 *@author Lihuanghe(18852780@qq.com) 
 */
public enum SessionState {
	DisConnect, Connect
}
