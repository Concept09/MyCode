package org.marre.sms;

/**
 * Message Waiting Profiles
 */
public enum MwiProfile {
    /** Profile ID 1. (Default) */
    ID_1,
    /** Profile ID 2. */
    ID_2,
    /** Profile ID 3. */
    ID_3,
    /** Profile ID 4. */
    ID_4,
}
